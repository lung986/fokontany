<?php include('includes/head.html')?>
<?php include('includes/menu_haut.php')?>
<?php include('includes/left.php')?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
   <?php include('contenu/content.php');?>
  </div>
  <!-- /.content-wrapper -->

<?php include('includes/footer.php')?>
  

  

 
