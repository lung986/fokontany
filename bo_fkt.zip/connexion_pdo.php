<?php
  define('DB_SERVEUR', 'localhost');
 
  // Login
  define('DB_LOGIN','root');
 
  // Mot de passe
  define('DB_PASSWORD','');
 
  // Nom de la base de données
  define('DB_NOM','bdd_fokotany');
  
 define('DB_DSN','mysql:host='. DB_SERVEUR .';dbname='. DB_NOM);
 
 
 function PDOConnect($sDbDsn, $sDbLogin, $sDbPassword) 
{
  try
  {
    $oPDO = new PDO($sDbDsn, $sDbLogin, $sDbPassword);
  }
  catch (PDOException $e)
  {
    die('Connexion impossible');
  }
 
  $oPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
  return $oPDO;
}

//appel de la fonction
//tableau datagrid pour la liste des membres du golf
$oPDO = null;
$oPDOStatement = null;
$oPDO = PDOConnect(DB_DSN, DB_LOGIN, DB_PASSWORD);
//selection utilisateur
$select = 'SELECT id_user, nom, prenom FROM nom_table ORDER BY prenom ASC';
$oPDOStatement = $oPDO->prepare($select);
$oPDOStatement->execute(); 
// Récupération des résultats sélectionnés dans le tableau $aListeMessages
$rowuser = $oPDOStatement->fetchAll(PDO::FETCH_OBJ);

						foreach ($rowuser as $oContent) 
						{			
							if($filtre == $oContent->id_user)
							{
								$selected="selected='selected'";
							}
							else
							{
								$selected="";
							}
							echo '<option value='.(int)$oContent->id_user.' '.$selected.'>'.utf8_encode($oContent->prenom)." ".utf8_encode($oContent->nom).'</option>';						
						}
									


?>

<?php
//Autre fonction
function testUserAction($user, $role)
{
	$oPDO = null;
	$oPDOStatement = null;
	$oPDO = PDOConnect(DB_DSN, DB_LOGIN, DB_PASSWORD);	
	$select = 'select * from tbl_role where user_id = "'.$user. '" AND client_action_id = '.$role;
	$oPDOStatement = $oPDO->prepare($select);
	$oPDOStatement->execute();	
	$num_rows = $oPDOStatement->rowCount();	
	if($num_rows > 0)
	{
		return true;
	}
	else{
		return false;
	}		
}
if (testUserAction(1, 'admin'))
{
	echo 'admin';
	

else {
	echo "tsy admin';
}
?>
